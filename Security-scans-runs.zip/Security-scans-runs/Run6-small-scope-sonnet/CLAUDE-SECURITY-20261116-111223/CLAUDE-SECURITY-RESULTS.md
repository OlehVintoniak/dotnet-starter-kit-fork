# Claude Security results

This scan covered `src/BuildingBlocks/Web` in `C:\projects\dotnet-starter-kit-fork` at commit `2f5989b2` on branch `main`, in scan mode, at `medium` effort, focused on production code (tests, fixtures, and generated code treated as background). It ran on 2026-11-16 and surfaced 2 verified findings: 1 MEDIUM and 1 LOW.

## Coverage

The scope was partitioned into three components, all fully read (60 of 60 tracked files, nothing unaccounted for):

- **web-request-security-pipeline** — `Auth`, `Security`, `RateLimiting`, `Idempotency`, `TrustedProxy`, `Cors`, `Exceptions`, `Frontend`, `FeatureFlags`, `Origin`
- **web-realtime-connections** — `Realtime`, `Sse`, `Health`, `OpenApi`
- **web-infrastructure-and-module-wiring** — `Mediator`, `Modules`, `Observability`, `HttpResilience`, `Validation`, `Versioning`, `Localization`, plus `Extensions.cs`, `IFshWeb.cs`, `Web.csproj`

11 researchers were dispatched across injection/input, authentication/authorization, and cryptography/secrets lenses (one pass per component per lens), plus one broader sweep and one dedicated secrets pass over the wider tree; all 11 returned. Each component's researchers left a handful of files as declared background rather than reading them in full — small interface/POCO/constants files with no input handling, and files outside their assigned component paths (consulted only via grep where needed to rule out a sink, e.g. confirming `/openapi` is gated off by default in production, and that `PagedQueryValidator`'s dynamic-sort consumers live in `src/Modules`, out of this scope). None of this left any in-scope file unread to a conclusion.

None of the three components' researchers were asked about memory-safety bugs (`web-request-security-pipeline:memory-and-unsafe`, `web-realtime-connections:memory-and-unsafe`, `web-infrastructure-and-module-wiring:memory-and-unsafe`) — the workflow decided from the language alone, before researchers were briefed, that this is managed C# code.

This was a scoped scan, so the whole-repository top-level-directory completeness check does not apply here. The verification panel ran a single round (verification run 1 of 1); no candidate was lost or left unverified.

## Findings

### F1 — Presence snapshot endpoint leaks any user's online status to any authenticated caller, cross-tenant, with no relationship check (MEDIUM, confidence high)

**Impact.** Any authenticated user of the platform, from any tenant, can query the live online/offline status of arbitrary user GUIDs across the entire deployment — a cross-tenant presence-leak / user-enumeration primitive. The hub's own real-time broadcast path explicitly scopes `PresenceChanged` events to the caller's tenant group (`AppHub.cs:93-123`), so this endpoint undermines the tenant isolation the rest of the component maintains.

**Where.** `src/BuildingBlocks/Web/Realtime/HeroRealtimeExtensions.cs:56` in the `GET /api/v1/realtime/presence` handler — CWE-639 (also CWE-862)

**What.** The `userIds` query parameter is split directly from client input and passed as-is to `presence.GetStatus(ids)`, which looks each id up in a process-wide, tenant-agnostic `ConcurrentDictionary<string,int>` singleton (`PresenceTracker.cs`). The only gate is `.RequireAuthorization()` — any authenticated user of any tenant — with no check that the caller shares a tenant, channel, or any other relationship with the requested ids.

**Exploit scenario.** A low-privileged user in Tenant A authenticates, obtains a JWT, then calls `GET /api/v1/realtime/presence?userIds=<guid-from-tenant-B>,<guid-from-tenant-B-2>` and receives each target's live online/offline status, despite having no membership or relationship with Tenant B or its users.

**Preconditions.**
- Caller must be authenticated (any valid JWT for the deployment, any tenant or role).
- Caller must know or guess target user GUIDs — not enumerable from this endpoint alone, but often discoverable via other IDOR-prone endpoints, shared channels, or references elsewhere in the app.

**Fix.** Scope the presence lookup to users the caller is actually allowed to see — same tenant and/or shared channel membership — before querying `IPresenceTracker`, mirroring the tenant-group scoping `AppHub.OnConnectedAsync` already applies to the broadcast path, instead of trusting a raw caller-supplied id list.

**Verification.** 3/3 lens verifiers confirmed.

### F2 — SSE token consume-and-delete is not atomic, letting a single-use stream token authenticate more than one concurrent stream (LOW, confidence medium)

**Impact.** Weakens the single-use guarantee on SSE stream tokens: a token that leaks — it travels in the query string by design, so it is exposed to proxy/server access logs, browser history, and `Referer` headers — can authenticate two or more concurrent SSE streams instead of exactly one, extending the usable window for a leaked token beyond its intended single consumption.

**Where.** `src/BuildingBlocks/Web/Sse/SseTokenService.cs:43` in `SseTokenService.ConsumeAsync` — CWE-362

**What.** `ConsumeAsync` is the sole authorization check for the `AllowAnonymous` `/api/v1/sse/stream` endpoint. It reads the token payload from the distributed cache, then deletes it in a separate, non-atomic step (`cache.RemoveAsync` a few lines later). Two requests presenting the same token concurrently can both read the payload before either delete completes, both passing the authorization gate.

**Exploit scenario.** A token leaks via a server/proxy access-log entry shortly after issuance. Before the legitimate client's single consumption completes its `RemoveAsync` call, an attacker who scraped the log replays the same token, and both the legitimate client and the attacker establish live SSE streams receiving the same user's real-time events.

**Preconditions.**
- Attacker (or a second party) must already possess a valid, unexpired (30s) SSE token, typically via leakage through logs, `Referer`, or history, since the token is carried in the query string by design.
- Requests must race within the same tens-of-milliseconds window before the first consumer's `RemoveAsync` completes.

**Fix.** Make consumption atomic — e.g. use an atomic get-and-delete primitive (Redis `GETDEL`) or a distributed lock/compare-and-swap — so only the first reader of a given token can ever obtain the payload.

**Verification.** 3/3 lens verifiers confirmed.

## What was verified

Both findings came from a researcher pass across three components (injection/input, auth/authz, and crypto/secrets lenses, plus a broad sweep and a secrets-specific pass), followed by a three-lens adversarial panel — reachability, impact, and defenses — that reviewed each candidate independently before it was kept. F1 and F2 each passed all three lenses unanimously (3/3). This scan is stamped `verified`; no code was executed, no exploit was run, and no proof-of-concept was validated — every finding is derived from reading the code.
