# Claude Security results

Scanned `src/Modules/Webhooks` (44 tracked files) on branch `main` at commit 83e9b1ec on 2026-11-17 at medium effort. Found 1 MEDIUM-severity vulnerability that survived panel verification.

## Coverage

The scan examined two components in the Webhooks module: the API contracts and endpoints (`webhooks-api-contracts`), and the services, data layer, and domain logic (`webhooks-dispatch-and-data`). Nine researchers were dispatched across vulnerability categories and both components and all returned, covering injection and input handling, authentication and authorization, memory and unsafe operations, and cryptography and secrets in both. The researchers' own account shows 41 of the 44 target files were read to a conclusion; 3 files lie under researcher-declared not-reached paths (localization resources and contracts directories where researchers had examined all relevant entries).

Two components outside the scoped target were deliberately skipped: the EF Core migrations in `src/Host/FSH.Starter.Migrations.PostgreSQL/Webhooks` (generated schema code, a downstream data-flow target but containing no independent logic to audit), and integration test fixtures in `src/Tests/Integration.Tests/Tests/Webhooks` (test code exercising, not implementing, the attacker-facing surface).

## Findings

### F1 — Missing validation for webhook signing secret strength (MEDIUM, confidence medium)

**Impact.** An attacker who obtains a webhook endpoint and captures a payload with its signature can brute-force the HMAC-SHA256 signing secret if it is weak enough, then forge valid signatures for malicious payloads to manipulate webhook deliveries.

**Where.** `src/Modules/Webhooks/Modules.Webhooks/Features/v1/CreateWebhookSubscription/CreateWebhookSubscriptionCommandValidator.cs:9` in `CreateWebhookSubscriptionCommandValidator` — CWE-521

**What.** The `CreateWebhookSubscriptionCommand` accepts an optional `Secret` field that is used directly as an HMAC-SHA256 key for signing webhooks (in `WebhookPayloadSigner.cs`), but the validator applies no rules to it — no minimum length, no complexity requirement. Users can provide arbitrarily weak secrets like `'a'` or `'123'`, which remain weak cryptographic keys.

**Exploit scenario.** An attacker discovers a webhook endpoint (e.g., from application logs or error responses) and captures a payload with its `X-Webhook-Signature` header. Using the weak signing secret, the attacker brute-forces it—a 4-character secret can be tested in seconds—then forges valid signatures for payloads of their choosing. The webhook endpoint accepts these as legitimate and processes attacker-controlled data.

**Preconditions.**
- User can create webhook subscriptions.
- User provides a weak secret instead of a cryptographically random one.
- Attacker obtains a webhook payload and its signature.

**Fix.** Add validation on the `Secret` field: (1) require it to be non-empty if provided, (2) enforce a minimum length of at least 32 characters, (3) document that secrets must be cryptographically random, not user-chosen passphrases.

**Verification.** 2/3 lens verifiers confirmed. One verifier (reachability) voted false positive, citing the endpoint's permission guard (`RequirePermission(WebhooksPermissions.Subscriptions.Create)`), but two verifiers (impact and defenses) confirmed the vulnerability's real impact (no validation on the secret field) and confirmed that permission guards do not stop users from providing weak secrets themselves.

## What was verified

This scan used the full medium-effort pipeline: an inventory of the target, a threat model, one researcher per component and category, a breadth sweep of unexamined code, and a three-lens adversarial panel voting on reachability, impact, and defenses. The result is verified — the finding earned 2 of 3 panel votes and all 9 researchers returned with their readings. Scans are nondeterministic; running them regularly on the codebase builds coverage over time and complements SAST, dependency scanning, and code review.
