# Security Scan Results

**Revision:** 2f5989b243d702e0e2f089bd0258117da05f32e7  
**Scan:** `src/BuildingBlocks/Web` (60 files) — medium effort  
**Coverage:** Complete, all 10 researchers returned  
**Findings:** 1 verified

## Summary

**1 vulnerability** with MEDIUM severity (HIGH confidence).

---

## Findings

### Missing authorization check on user presence query

**Severity:** MEDIUM · **Confidence:** HIGH · **CWE:** CWE-862  
**File:** `src/BuildingBlocks/Web/Realtime/HeroRealtimeExtensions.cs:56`

#### Description

The presence endpoint accepts user IDs from the query string and passes them directly to `GetStatus()` without authorization checks, allowing any authenticated user to query the online presence of any other user.

**Impact:** User enumeration and activity pattern disclosure — attackers can determine if specific users are online.

#### Exploit scenario

An authenticated user requests `/api/v1/realtime/presence?userIds=other_user_id` and receives their online status without permission.

#### Preconditions

- User is authenticated
- Attacker knows target user IDs

#### Recommendation

Add authorization checks to ensure users can only query presence for users in the same channels/teams, or add explicit permission requirements.

#### Code

```csharp
var map = presence.GetStatus(ids);
```

---

## Coverage

The scan examined 3 components across the `src/BuildingBlocks/Web` scope:

1. **web-request-pipeline-security** — Auth, Security, CORS, rate limiting, idempotency, feature flags, trusted proxy, origin, frontend, exceptions
2. **web-realtime-and-api-infra** — Realtime, SSE, health, HTTP resilience, OpenAPI, versioning, Mediator, validation  
3. **web-bootstrap-and-observability** — Modules, observability, localization, extension point, interface

All 10 researchers completed analysis across injection/input handling, authentication/authorization, and cryptography/secrets categories. Coverage is complete with no truncation or researcher loss.

