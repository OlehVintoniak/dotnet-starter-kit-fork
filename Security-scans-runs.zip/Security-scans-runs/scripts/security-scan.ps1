
$log = "claude-security-run.jsonl"

claude -p `
  --model claude-haiku-4-5 `
  --permission-mode auto `
  --add-dir "C:\projects\dotnet-starter-kit-fork" `
  --output-format stream-json `
  --verbose `
  --include-partial-messages `
  "/claude-security scan the src\BuildingBlocks\Web with medium effort. I understand that it will take a lot of time and tokens." |
  Tee-Object -FilePath $log

# Extract final cost
$final = Get-Content $log -Tail 1 | ConvertFrom-Json

Write-Host "`n================================"
Write-Host "Security scan completed"
Write-Host "Total cost: `$$($final.total_cost_usd)"
Write-Host "Duration: $([math]::Round($final.duration_ms / 1000, 2)) seconds"
Write-Host "Input tokens: $($final.usage.input_tokens)"
Write-Host "Output tokens: $($final.usage.output_tokens)"
Write-Host "================================"
