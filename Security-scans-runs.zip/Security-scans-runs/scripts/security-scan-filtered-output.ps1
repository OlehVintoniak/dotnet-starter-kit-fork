# Disable the background-task wait timeout
$env:CLAUDE_CODE_PRINT_BG_WAIT_CEILING_MS = "0"

# Correct decoding of claude output (avoids mojibake like "ΓÇö")
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$log = "C:\projects\security-scan-filtered-output.jsonl"

claude -p `
  --model claude-haiku-4-5 `
  --permission-mode auto `
  --add-dir "C:\projects\dotnet-starter-kit-fork" `
  --output-format stream-json `
  --verbose `
  --include-partial-messages `
  "/claude-security scan the dotnet-starter-kit-fork\src\Modules\Webhooks folder with medium effort. I understand that it will take a lot of time and tokens." |
  ForEach-Object -Begin   { $writer = New-Object System.IO.StreamWriter($log, $false, (New-Object System.Text.UTF8Encoding($false))); $writer.AutoFlush = $true } `
                 -Process {
                     $writer.WriteLine($_)                       # raw log
                     try { $e = $_ | ConvertFrom-Json } catch { Write-Host $_; return }   # non-JSON line (e.g. stderr text): show as-is
                     if ($e.type -eq 'stream_event' -and $e.event.delta.type -eq 'text_delta') {
                         Write-Host -NoNewline $e.event.delta.text
                     }
                     elseif ($e.type -eq 'system') {
                         switch ($e.subtype) {
                             'task_started'      { Write-Host "`n[STARTED] $($e.description)"  -ForegroundColor Green }
                             'task_progress'     { Write-Host "`n[PROGRESS] $($e.description)" -ForegroundColor DarkGray }
                             'task_notification' { Write-Host "`n[TASK] $($e.summary)"         -ForegroundColor Cyan }
                             'permission_denied' { Write-Host "`n[PERMISSION] $($e.message)"   -ForegroundColor Yellow }
                         }
                     }
                     elseif ($e.type -eq 'result') {
                         Write-Host "`n[RESULT] $($e.subtype)" -ForegroundColor Cyan
                     }
                 } `
                 -End     { $writer.Dispose() }

# Extract final metrics (only if the run produced a result line)
$final = Get-Content $log -Encoding utf8 | Where-Object { $_ -match '"type":"result"' } | Select-Object -Last 1
if ($final) {
    $final = $final | ConvertFrom-Json
    Write-Host "`n--- SCAN METRICS ---" -ForegroundColor Cyan
    Write-Host "Cost:          `$$($final.total_cost_usd)"
    Write-Host "Input tokens:  $($final.usage.input_tokens)"
    Write-Host "Output tokens: $($final.usage.output_tokens)"
    Write-Host "Duration:      $($final.duration_ms / 1000) seconds"
} else {
    Write-Host "`nNo result event in log (run was interrupted or hit a limit)." -ForegroundColor Yellow
}
