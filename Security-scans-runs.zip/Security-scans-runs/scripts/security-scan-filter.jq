if .type == "stream_event" and .event.delta.type? == "text_delta" then
    .event.delta.text
elif .type == "system" and .subtype == "task_started" then
    "\n[STARTED] " + (.description // "") + "\n"
elif .type == "system" and .subtype == "task_progress" then
    "\n[PROGRESS] " + (.description // "") + "\n"
elif .type == "system" and .subtype == "task_notification" then
    "\n[TASK] " + (.summary // "") + "\n"
elif .type == "system" and .subtype == "permission_denied" then
    "\n[PERMISSION] " + (.message // "") + "\n"
elif .type == "result" then
    "\n[RESULT] " + (.subtype // "") + "\n"
else empty
end
